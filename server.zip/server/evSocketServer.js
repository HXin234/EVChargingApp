/**
 * evSocketServer.js
 * EV Charging Management App — Socket.IO WebSocket Server
 *
 * Namespace: /charging
 *
 * Events received from client:
 *   client_connected  { connected: true }
 *   request_status    { stationId: string, stationName: string }
 *
 * Events emitted to client:
 *   status_update     { stationId, stationName, available, waitTime, powerOutput, message }
 *
 * Run:
 *   node evSocketServer.js        (default port 5001)
 *
 * Requires:
 *   npm install express socket.io
 *
 * NOTE: Run this alongside evServer.js (which uses port 5000).
 *       This server uses port 5001 to avoid conflict.
 */

const express = require('express');
const http    = require('http');
const { Server } = require('socket.io');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
  cors: { origin: '*' },
});

// ─── Simulated station data ───────────────────────────────────────────────────
// In a real system this would be pulled from a live database.
const stationStatus = {
  '1': { stationName: 'KLCC EV Station',    available: 2, totalSlots: 4, powerOutput: 22, waitTime: 0  },
  '2': { stationName: 'Cyberjaya EV Point', available: 6, totalSlots: 8, powerOutput: 50, waitTime: 0  },
  '3': { stationName: 'Putrajaya EV Hub',   available: 0, totalSlots: 5, powerOutput: 22, waitTime: 35 },
};

// ─── Namespace /charging ──────────────────────────────────────────────────────
const charging = io.of('/charging');

charging.on('connection', (socket) => {
  console.log(`[Socket.IO] Client connected: ${socket.id}`);

  // ── client_connected ──────────────────────────────────────────────────────
  socket.on('client_connected', (data) => {
    console.log(`[Socket.IO] client_connected event — connected: ${data.connected}`);
  });

  // ── request_status ────────────────────────────────────────────────────────
  // The client sends the stationId it wants live status for.
  // The server looks up the station, adds a small random fluctuation to
  // simulate real-time changes, then emits status_update back.
  socket.on('request_status', (data) => {
    const { stationId } = data;
    const station = stationStatus[stationId];

    if (!station) {
      socket.emit('status_update', { error: 'Station not found.' });
      return;
    }

    // Simulate minor real-time fluctuation in available slots (for demo)
    const fluctuation = Math.floor(Math.random() * 3) - 1; // -1, 0, or +1
    const liveAvailable = Math.min(
      station.totalSlots,
      Math.max(0, station.available + fluctuation)
    );

    const response = {
      stationId,
      stationName: station.stationName,
      available:   liveAvailable,
      totalSlots:  station.totalSlots,
      powerOutput: station.powerOutput,
      waitTime:    liveAvailable === 0 ? station.waitTime : 0,
      message:
        liveAvailable > 0
          ? `${liveAvailable} slot(s) available — ready to charge!`
          : `Station full. Estimated wait: ${station.waitTime} min.`,
    };

    console.log(`[Socket.IO] Emitting status_update for station ${stationId}:`, response);
    socket.emit('status_update', response);
  });

  // ── disconnection ─────────────────────────────────────────────────────────
  socket.on('disconnect', () => {
    console.log(`[Socket.IO] Client disconnected: ${socket.id}`);
  });
});

// ─── Start server ─────────────────────────────────────────────────────────────
const PORT = process.env.SOCKET_PORT || 5001;

server.listen(PORT, '0.0.0.0', () => {
  console.log(`EV Charging Socket.IO server running on port ${PORT}`);
});
